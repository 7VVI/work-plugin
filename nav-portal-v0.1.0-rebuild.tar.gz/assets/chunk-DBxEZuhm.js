function a(n){const f=Date.now()-n,e=Math.floor(f/1e3),t=Math.floor(e/60),r=Math.floor(t/60),o=Math.floor(r/24);return e<60?"刚刚":t<60?`${t} 分钟前`:r<24?`${r} 小时前`:o===1?"昨天":o<30?`${o} 天前`:new Date(n).toLocaleDateString("zh-CN")}export{a as f};
//# sourceMappingURL=chunk-DBxEZuhm.js.map
