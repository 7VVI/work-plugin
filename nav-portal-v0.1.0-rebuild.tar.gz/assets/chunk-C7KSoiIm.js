async function o(t){try{await navigator.clipboard.writeText(t)}catch{const e=document.createElement("textarea");e.value=t,e.style.position="fixed",e.style.opacity="0",document.body.appendChild(e),e.select(),document.execCommand("copy"),document.body.removeChild(e)}}export{o as c};
//# sourceMappingURL=chunk-C7KSoiIm.js.map
