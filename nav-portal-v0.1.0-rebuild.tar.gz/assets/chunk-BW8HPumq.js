(function(){function r(){const e=Array.from(document.querySelectorAll('input[type="password"]')),n=[];for(const t of e){if(t.hidden||t.disabled)continue;const i=t.closest("form"),o=y(t,i);o&&n.push({form:i,usernameField:o,passwordField:t,submitButton:h(i)})}return n}function y(e,n){const t=n||document;return Array.from(t.querySelectorAll('input[type="text"], input[type="email"], input:not([type])')).filter(o=>!o.hidden&&!o.disabled).filter(o=>x(o,e)<=0).sort((o,s)=>a(s,e)-a(o,e))[0]??null}function h(e){if(e){const n=e.querySelector('button[type="submit"], button:not([type])');if(n)return n}return document.querySelector('button[type="submit"]')??void 0}function x(e,n){if(e===n)return 0;const t=e.compareDocumentPosition(n);return t&Node.DOCUMENT_POSITION_FOLLOWING?-1:t&Node.DOCUMENT_POSITION_PRECEDING?1:0}function a(e,n){const t=e.getBoundingClientRect(),i=n.getBoundingClientRect();return Math.abs(t.top-i.top)+Math.abs(t.left-i.left)}async function p(e,n){c(e.usernameField,n.username),c(e.passwordField,n.plainPassword),e.usernameField.dispatchEvent(new Event("input",{bubbles:!0})),e.passwordField.dispatchEvent(new Event("input",{bubbles:!0})),e.usernameField.dispatchEvent(new Event("change",{bubbles:!0})),e.passwordField.dispatchEvent(new Event("change",{bubbles:!0}))}function c(e,n){Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,"value")?.set?.call(e,n)}function f(){const e=document.createElement("div");e.textContent="✓ Nav Portal 已填充",e.style.cssText=`
    position: fixed; top: 16px; right: 16px; z-index: 2147483647;
    background: #10b981; color: white; padding: 8px 14px;
    border-radius: 6px; font-size: 13px; font-family: sans-serif;
    box-shadow: 0 4px 12px rgba(0,0,0,0.15); transition: opacity 0.3s;
  `,document.body.appendChild(e),setTimeout(()=>{e.style.opacity="0",setTimeout(()=>e.remove(),300)},1500)}function v(e,n){const t=document.createElement("div");t.id="nav-portal-picker-host",t.style.cssText="position: fixed; top: 16px; right: 16px; z-index: 2147483647;";const i=t.attachShadow({mode:"closed"});i.innerHTML=`
    <style>
      .panel { background: white; border: 1px solid #e5e7eb; border-radius: 8px;
               box-shadow: 0 8px 24px rgba(0,0,0,0.15); padding: 8px; min-width: 240px;
               font-family: -apple-system, BlinkMacSystemFont, sans-serif; }
      .title { font-size: 12px; color: #6b7280; padding: 4px 8px; }
      .item { display: flex; align-items: center; gap: 8px; padding: 8px;
              border-radius: 6px; cursor: pointer; font-size: 13px; color: #111827; }
      .item:hover { background: #f3f4f6; }
      .role { font-size: 11px; padding: 1px 6px; border-radius: 3px; background: #eff6ff; color: #1d4ed8; }
    </style>
    <div class="panel">
      <div class="title">选择要填充的账号</div>
      ${e.map((o,s)=>`
        <div class="item" data-idx="${s}">
          <span class="role">${o.account.role}</span>
          <span>${o.account.username}</span>
        </div>
      `).join("")}
    </div>
  `,document.body.appendChild(t),i.querySelectorAll(".item").forEach(o=>{o.addEventListener("click",async()=>{const s=Number(o.dataset.idx),b=e[s];await p(n[0],b.account),f(),t.remove()})}),setTimeout(()=>{document.addEventListener("click",function o(s){t.contains(s.target)||(t.remove(),document.removeEventListener("click",o))})},100),document.addEventListener("keydown",function o(s){s.key==="Escape"&&(t.remove(),document.removeEventListener("keydown",o))})}function g(e){chrome.runtime.onMessage.addListener((n,t,i)=>{e(n)})}let u=!1,l=!1;function d(){if(u)return;const e=r();e.length>0&&(u=!0,chrome.runtime.sendMessage({type:"PAGE_HAS_LOGIN_FORM",count:e.length}))}d();window.addEventListener("DOMContentLoaded",()=>{d()});const m=new MutationObserver(()=>{d()});m.observe(document.documentElement,{childList:!0,subtree:!0});setTimeout(()=>m.disconnect(),1e4);g(async e=>{if(e.type!=="AUTO_FILL"||!e.payload||l)return;let n=r();if(n.length===0&&(await new Promise(i=>setTimeout(i,300)),n=r()),n.length===0)return;l=!0;const t=e.payload;"picker"in t?v(t.picker,n):(await p(n[0],t.account),f())});
//# sourceMappingURL=chunk-BW8HPumq.js.map
})()
